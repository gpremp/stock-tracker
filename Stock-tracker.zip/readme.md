create a database in mongodb with database name "stock-management"

provide the mongodb database connection string in server/src/config/config.js

run "npm install" command to install all dependencies in both frontend and server

To run the node.js server "npm start" command is used To run the react.js frontend "npm start" command is used