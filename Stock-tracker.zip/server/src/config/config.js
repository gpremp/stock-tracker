 const DB = "mongodb://localhost:27017/stock-management"


module.exports = { DB};